﻿const nodemailer = require('nodemailer')
const env = require('../config/env')

let transporter

const getTransporter = () => {
  if (!env.smtp.user || !env.smtp.pass) return null
  if (!transporter) {
    transporter = nodemailer.createTransport({
      host: env.smtp.host,
      port: env.smtp.port,
      secure: env.smtp.secure,
      auth: {
        user: env.smtp.user,
        pass: env.smtp.pass,
      },
      connectionTimeout: 5000,
      greetingTimeout: 5000,
      socketTimeout: 5000,
    })
  }
  return transporter
}

const sendMail = async ({ to, subject, text }) => {
  const smtp = getTransporter()
  if (!smtp) {
    console.log(`[mail:dev] to=${to} subject="${subject}" ${text}`)
    return { sent: false, reason: 'SMTP credentials missing; email printed in backend terminal.' }
  }

  try {
    const info = await smtp.sendMail({ from: env.smtp.from, to, subject, text })
    return { sent: true, messageId: info.messageId }
  } catch (error) {
    console.log(`[mail:error] to=${to} subject="${subject}" ${error.message}`)
    return { sent: false, reason: error.message }
  }
}

module.exports = { sendMail }
